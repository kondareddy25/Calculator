package com.org.util;

public class CalculateFactory {
	
	public static Calculator getOperatorClass(String className){
		Calculator calculator=null;
		if(className.equals("Addition"))
			calculator=  new AdditionClass();
		else if(className.equals("Subtraction"))
			calculator = new SubtractionClass();
		else if(className.equals("Multiplication"))
			calculator = new MultiplicationClass();
		else if(className.equals("Division"))
			calculator= new DivisionClass();
		
		return calculator;
	}

}
