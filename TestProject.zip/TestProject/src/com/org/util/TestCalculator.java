package com.org.util;

import java.math.BigDecimal;
import java.util.InputMismatchException;
import java.util.Scanner;

public class TestCalculator {
	
	public static <T extends Number> double calculate(BigDecimal firstParam,BigDecimal secondParam,String operator){
		Calculator calculator = CalculateFactory.getOperatorClass(operator);
		return calculator.calculate(firstParam, secondParam);
	}	
	public static void main(String[] args) {		
		Scanner input = new Scanner(System.in);
		try{
		System.out.println("Please Enter First Parameter");
		BigDecimal firstParam = input.nextBigDecimal();
		System.out.println("Please Enter second Parameter");
		BigDecimal secondParam = input.nextBigDecimal();
		System.out.println("Please enter operators fromt he list + - / *");
		String operator = input.next();
		switch(operator){
		case "+": System.out.println("Addition of two numbers:"+ calculate(firstParam, secondParam, "Addition"));break;
		case "-": System.out.println("Subtraction of two numbers:"+calculate(firstParam, secondParam, "Subtraction"));break;
		case "*": System.out.println("Multiplication of two numbers:"+calculate(firstParam, secondParam, "Multiplication"));break;
		case "/": System.out.println("Division of two numbers:"+calculate(firstParam, secondParam, "Division"));break;
		default : throw new InputMismatchException("Please Enter operators from the list only");
		}
		main(args);
		} catch(InputMismatchException inmismatchException) {
			System.out.println("Eneter correct inputs");
			main(args);
		} catch(Exception exp) {
			System.out.println("System Error Occured");
		}
		finally {
			input.close();
		}
	}
}
