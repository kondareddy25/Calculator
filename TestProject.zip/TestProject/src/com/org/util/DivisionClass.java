package com.org.util;

public class DivisionClass implements Calculator {
	
public <T extends Number> double calculate(T firstParam,T secondParam){
		
		return firstParam.doubleValue() / secondParam.doubleValue();
	}

}
