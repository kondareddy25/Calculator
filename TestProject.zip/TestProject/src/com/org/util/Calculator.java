package com.org.util;

public interface Calculator {
	
	public <T extends Number> double calculate(T firstParam,T secondParam);

}
