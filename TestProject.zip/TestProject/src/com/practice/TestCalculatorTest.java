package com.practice;


import java.math.BigDecimal;

import org.junit.Assert;
import org.junit.Test;

import com.org.util.TestCalculator;

public class TestCalculatorTest {
	
	TestCalculator testCalculator;
	public void init(){
		testCalculator = new TestCalculator();
	}

	@Test
	public void testAddition() {
		TestCalculator.calculate(new BigDecimal(20.0), new BigDecimal(30.0), "Addition");
		Assert.assertEquals("50.0", String.valueOf(TestCalculator.calculate(new BigDecimal(20.0), new BigDecimal(30.0), "Addition")));
	
	}
	@Test
	public void testSubtraction() {
		Assert.assertEquals("-10.0",String.valueOf(TestCalculator.calculate(new BigDecimal(20.0), new BigDecimal(30.0), "Subtraction")));
	}
	@Test
	public void testMultiplication() {
		Assert.assertEquals("600.0",String.valueOf(TestCalculator.calculate(new BigDecimal(20.0), new BigDecimal(30.0), "Multiplication")));
	}
	@Test
	public void testDivision() {
		Assert.assertEquals("2.0" ,String.valueOf(TestCalculator.calculate(new BigDecimal(60.0), new BigDecimal(30.0), "Division")));
	}

}
